package com.example.prviewmodel

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import coil3.load
import com.example.prviewmodel.databinding.ActivityMainBinding
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    private val estilos = arrayOf("avataaars","bottts","adventurer", "lorelei")
    private val listaFavs = mutableListOf<Avatar>()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        binding.ivAvatar.setImageResource(R.drawable.baseline_person_24)



        //Listener al botón bGenerarAvatar.
        //Debe generar el avatar y actualizar el estado del checkbox en función de si es o no es favorito.


        //Listener al checkBox -> Insertará o eliminará de favoritos.

    }

    override fun onResume() {
        super.onResume()
        (binding.cbEstilo.editText as MaterialAutoCompleteTextView).setSimpleItems(estilos)
    }

    private fun obtenerAvatar() : Avatar {
        //Devuelve un objeto avatar.
        //binding.tfCadena.editText!!.text.toString()
        //binding.cbEstilo.editText!!.text.toString()
        return Avatar("","")
    }

    private fun generarAvatar() {
        //NOTA: En una entrega debería haber validación de datos.

        //Obtiene los valores insertados y carga la imagen.
        val cadena = ""
        val estilo = ""
        binding.ivAvatar.load("https://api.dicebear.com/9.x/$estilo/svg?seed=$cadena")
    }

    private fun eliminarFav() {
        //Debe obtener el avatar y borrarlo de la lista de favoritos.
    }

    private fun insertarFav() {
        //Debe obtener el avatar y añadirlo a la lista de favoritos.
    }

    private fun esFavorito() : Boolean {
        //Debe obtener el avatar y devolverlo si está incluido o no en la lista de favoritos.
        return true
    }




}