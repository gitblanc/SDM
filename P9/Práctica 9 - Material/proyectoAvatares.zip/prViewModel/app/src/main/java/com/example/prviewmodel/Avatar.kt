package com.example.prviewmodel

data class Avatar(val identificador: String, val estilo : String)
