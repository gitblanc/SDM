package es.uniovi.eii.sdm.buscarciudadc.data

data class Ciudad(val nombre:String, val latitud: Double, val longitud: Double)