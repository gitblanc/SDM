    /*****************************************************************************************
     * Gestión geolocalización (previamente creamos el cliente y gestionamos permisos)
     *****************************************************************************************/

    /**
     * Obtiene la mejor y más reciente ubicación disponible actualmente,
     * que puede ser nula en casos excepcionales cuando una ubicación no está disponible.
     */
    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        fusedLocationClient.lastLocation
            .addOnCompleteListener { taskLocation ->
                if (taskLocation.isSuccessful && taskLocation.result != null) {
                    Log.d(TAG, "leemos localizacion gps", taskLocation.exception)
                    val location = taskLocation.result
                    if (location!=null) {
                        aquiEstoy= LatLng(location.latitude,location.longitude)
                    }
                } else {
                    Log.w(TAG, "getLastLocation:exception", taskLocation.exception)
                    showSnackbar(R.string.no_location_detected)
                }
            }
    }
