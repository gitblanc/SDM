
    /*****************************************************************************************
     * Gestión de permisos
     *****************************************************************************************/
    companion object {
        const val REQUEST_PERMISSIONS_REQUEST_CODE= 0
    }


    /** Devuelve el estado actual del permiso ACCESS_COARSE_LOCATION   */
    private fun checkPermissions() =
        ActivityCompat.checkSelfPermission(this, ACCESS_COARSE_LOCATION) == PERMISSION_GRANTED

    /** Gestiona la solicitud de permisos */
    private fun requestPermissions() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, ACCESS_COARSE_LOCATION)) {
            // Proporciona una explicación adicional al usuario. Esto podría pasar si el usuario
            // ha denegado la petición previamente, pero no marca el checkbox de "No preguntar de nuevo"
            Log.i(TAG, "Muestra la explicación de la necesidad del permiso.")
            showSnackbar(R.string.permission_rationale, android.R.string.ok, View.OnClickListener {
                // Solicita permiso
                startLocationPermissionRequest()
            })

        } else {
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the user denied the permission
            // previously and checked "Never ask again".
            Log.i(TAG, "Solicitud de permiso")
            startLocationPermissionRequest()
        }
    }

    /** Lanza la petición de permisos ACCESS_COARSE_LOCATION */
    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(this, arrayOf(ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE)
    }

    /** Gestina la aprobación o denegación del permiso por parte del usuario */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                // Si la interacción del usuario fue interrumpida, la petición del permiso se
                // cancela y recibe un array vacío
                grantResults.isEmpty() -> Log.i(TAG, "La interacción del usuario fue cancelada.")

                // Permiso concedido
                (grantResults[0] == PackageManager.PERMISSION_GRANTED) -> getLastLocation()

                // Permiso denegado
                else -> {
                    // Notifica al usuario via SnackBar que ha denegado un permiso clave para la aplicación,
                    // lo cual hace que la activity carezca de sentido. En una app real, los permisos clave
                    // debe solicitarse en una pantalla de bienvenida

                    // Adicionalmente, es importante recordar que un permiso puede ser denegado
                    // sin preguntarle al usuario (por política del dispositivo o que previamente
                    // haya marcado "no volver a preguntar"). Por tanto, cuando los permisos se
                    // deniegan se implementa una interfaz para ofrecer al usuario que los cambie.
                    // Si no es así la app podría parecer que la app no responde a los toques o
                    // interacciones que tienen permisos requeridos.
                    showSnackbar(R.string.permission_denied_explanation, R.string.settings,
                        View.OnClickListener {
                            // Construye un intent que muestra la pantalla de settings de la App
                            val intent = Intent().apply {
                                action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                                data = Uri.fromParts("package", APPLICATION_ID, null)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            startActivity(intent)
                        })
                }
            }
        }
    }
