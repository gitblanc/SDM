class LocationProvider {
    suspend fun getUserLocation(Context: context): Location? {
        // comprobar los permisos
        isUserPermissionsGranted= true

        // comprobar si tengo habilitado alg�n tipo de proveedor de ubicaci�n en el m�vil
        val locationManager locationManager= 
            context.getSystemService(Context.LOCATION_SERVICE) as locationManager
        val isGPSEnabled=
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) 
                || locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        
        if (!isGPSEnabled || !isUserPermissionsGranted) {
            return null
        }

        // cliente para conectar al servicio de ubicaciones de Google
        val locationClient: FusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(context)
    
        return suspendCancellableCoroutine {
            locationClient.lastLocation.apply {
                if (isComplete) {
                    if (isSuccessful) {
                        cont.resume(result) {}
                    } else {
                        cont.resume(null) {}
                    }
                    return @suspendCancellableCoroutine
                }        
                addOnSuccessListener {
                    cont.resume(it) {}
                }
                addOnFauilureListener {
                    cont.resume(null) {}
                }
                addOnCanceledListener {
                    cont.resume(null) {}
                }
            }
        }

    
    }
}